from django.urls import path
from .views import login_view, callback, dashboard, logout_view

urlpatterns = [
    path('login/', login_view, name='login'),
    path('callback/', callback, name='callback'),
    path('dashboard/', dashboard, name='dashboard'),
    path('logout/', logout_view, name='logout'),
]
