import os
import secrets
import hashlib
import base64
import requests
from django.shortcuts import redirect, render
from django.http import JsonResponse
from django.contrib.auth import login, logout
from django.contrib.auth.models import User

# Load environment variables
OAUTH_CLIENT_ID = os.getenv("OAUTH_CLIENT_ID")
OAUTH_AUTHORIZE_URL = os.getenv("OAUTH_AUTHORIZE_URL")
OAUTH_TOKEN_URL = os.getenv("OAUTH_TOKEN_URL")
OAUTH_USERINFO_URL = os.getenv("OAUTH_USERINFO_URL")
OAUTH_REDIRECT_URI = os.getenv("OAUTH_REDIRECT_URI")
OAUTH_SCOPES = os.getenv("OAUTH_SCOPES")

CODE_VERIFIERS = {}

def generate_pkce():
    code_verifier = secrets.token_urlsafe(64)
    code_challenge = base64.urlsafe_b64encode(
        hashlib.sha256(code_verifier.encode()).digest()
    ).decode().rstrip("=")
    return code_verifier, code_challenge

def login_view(request):
    code_verifier, code_challenge = generate_pkce()
    state = secrets.token_urlsafe(16)
    
    CODE_VERIFIERS[state] = code_verifier

    auth_url = (
        f"{OAUTH_AUTHORIZE_URL}?"
        f"client_id={OAUTH_CLIENT_ID}"
        f"&response_type=code"
        f"&redirect_uri={OAUTH_REDIRECT_URI}"
        f"&scope={OAUTH_SCOPES}"
        f"&state={state}"
        f"&nonce={secrets.token_urlsafe(16)}"
        f"&code_challenge={code_challenge}"
        f"&code_challenge_method=S256"
        f"&response_mode=form_post"
    )

    return redirect(auth_url)

from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def callback(request):
    if request.method == "POST":
        code = request.POST.get("code")
        state = request.POST.get("state")

        if not code or state not in CODE_VERIFIERS:
            return JsonResponse({"error": "Invalid request"}, status=400)
        
        code_verifier = CODE_VERIFIERS.pop(state)

        token_response = requests.post(OAUTH_TOKEN_URL, data={
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": OAUTH_REDIRECT_URI,
            "client_id": OAUTH_CLIENT_ID,
            "code_verifier": code_verifier
        }, headers={"Content-Type": "application/x-www-form-urlencoded"})

        token_data = token_response.json()

        if "access_token" in token_data:
            access_token = token_data["access_token"]
            request.session["access_token"] = access_token

            headers = {"Authorization": f"Bearer {access_token}"}
            userinfo_response = requests.get(OAUTH_USERINFO_URL, headers=headers)
            userinfo = userinfo_response.json()

            email = userinfo.get("email")
            first_name = userinfo.get("given_name", "")
            last_name = userinfo.get("family_name", "")

            user, _ = User.objects.get_or_create(username=email, defaults={
                "email": email,
                "first_name": first_name,
                "last_name": last_name,
            })

            login(request, user)
            request.session["user"] = userinfo

            return JsonResponse({"message": "Login successful", "user": userinfo})

    return JsonResponse({"error": "Invalid request"}, status=400)

def logout_view(request):
    logout(request)
    request.session.flush()
    return JsonResponse({"message": "Logged out successfully"})
