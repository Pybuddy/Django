from django.urls import path
from .views import login_view, callback, logout_view

urlpatterns = [
    path('login/', login_view, name='login'),
    path('callback/', callback, name='callback'),
    path('logout/', logout_view, name='logout'),
]
